-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: randevu_sistemi
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$k02s4oRKW9j31yUiACBmcuVh5sJfTqi6OZSqOJUaaVt2NTj7SYtZS','2026-06-18 08:21:54');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment_series`
--

DROP TABLE IF EXISTS `appointment_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment_series` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `appointment_time` time NOT NULL,
  `frequency` enum('weekly','biweekly','monthly') NOT NULL,
  `day_of_week` tinyint(4) DEFAULT NULL,
  `day_of_month` tinyint(4) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `appointment_series_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `appointment_series_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment_series`
--

LOCK TABLES `appointment_series` WRITE;
/*!40000 ALTER TABLE `appointment_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `cancel_token` varchar(64) DEFAULT NULL,
  `payment_status` enum('pending','paid','refunded') DEFAULT 'pending',
  `payment_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `idx_employee` (`employee_id`),
  KEY `idx_customer` (`customer_id`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (1,1,NULL,NULL,'Test','test@test.com','5551234567','2026-06-23','10:00:00','','completed','2026-06-18 08:39:46',NULL,'pending',NULL),(2,2,NULL,NULL,'sd asdas','sdsdsd@gmail.com','05555556655','2026-06-26','16:47:00','teetst','completed','2026-06-18 09:44:41','12cff3173bcc1f5a7091c7057378ed8210917d2d098c9f59f765e76e52c1bbb5','pending',NULL);
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_ips`
--

DROP TABLE IF EXISTS `blocked_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `blocked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`),
  KEY `idx_ip` (`ip`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_ips`
--

LOCK TABLES `blocked_ips` WRITE;
/*!40000 ALTER TABLE `blocked_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `break_times`
--

DROP TABLE IF EXISTS `break_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `break_times` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) DEFAULT NULL,
  `day_of_week` tinyint(4) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `break_times`
--

LOCK TABLES `break_times` WRITE;
/*!40000 ALTER TABLE `break_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `break_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `total_appointments` int(11) DEFAULT 0,
  `total_spent` decimal(10,2) DEFAULT 0.00,
  `loyalty_points` int(11) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `last_visit` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_hours`
--

DROP TABLE IF EXISTS `employee_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_hours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `day_of_week` tinyint(4) NOT NULL,
  `is_open` tinyint(1) DEFAULT 1,
  `open_time` time DEFAULT '09:00:00',
  `close_time` time DEFAULT '18:00:00',
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `employee_hours_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_hours`
--

LOCK TABLES `employee_hours` WRITE;
/*!40000 ALTER TABLE `employee_hours` DISABLE KEYS */;
INSERT INTO `employee_hours` VALUES (1,1,0,0,'09:00:00','18:00:00'),(2,2,0,0,NULL,NULL),(3,1,1,1,'09:00:00','18:00:00'),(4,2,1,1,'09:00:00','18:00:00'),(5,1,2,1,'09:00:00','18:00:00'),(6,2,2,1,'09:00:00','18:00:00'),(7,1,3,1,'09:00:00','18:00:00'),(8,2,3,1,'09:00:00','18:00:00'),(9,1,4,0,'09:00:00','18:00:00'),(10,2,4,1,'09:00:00','18:00:00'),(11,1,5,1,'09:00:00','18:00:00'),(12,2,5,1,'09:00:00','18:00:00'),(13,1,6,1,'10:00:00','16:00:00'),(14,2,6,1,'10:00:00','16:00:00');
/*!40000 ALTER TABLE `employee_hours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Ahmet Yılmaz','ahmet@example.com','05321112233',1,'2026-06-18 09:51:14'),(2,'Ayşe Demir','ayse@example.com','05332223344',1,'2026-06-18 09:51:14');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `username` varchar(100) NOT NULL,
  `success` tinyint(1) DEFAULT 0,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip`),
  KEY `idx_attempted` (`attempted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (31,'::1','admin',1,'2026-06-18 09:58:21'),(32,'::1','admin',1,'2026-06-18 10:30:44');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rate_limits`
--

DROP TABLE IF EXISTS `rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rate_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `endpoint` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip_endpoint` (`ip`,`endpoint`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limits`
--

LOCK TABLES `rate_limits` WRITE;
/*!40000 ALTER TABLE `rate_limits` DISABLE KEYS */;
INSERT INTO `rate_limits` VALUES (491,'::1','/randv/admin/index.php?tab=customers','2026-06-18 10:45:17'),(492,'::1','/randv/admin/index.php?tab=settings','2026-06-18 10:45:18'),(493,'::1','/randv/admin/index.php?tab=bulk','2026-06-18 10:45:18'),(494,'::1','/randv/admin/index.php?tab=series','2026-06-18 10:45:19'),(495,'::1','/randv/admin/index.php?tab=appointments','2026-06-18 10:45:23'),(496,'::1','/randv/admin/index.php?tab=dashboard','2026-06-18 10:45:23'),(497,'::1','/randv/admin/index.php?tab=settings','2026-06-18 10:45:28'),(498,'::1','/randv/admin/index.php?tab=settings','2026-06-18 10:47:05'),(499,'::1','/randv/admin/index.php?tab=settings','2026-06-18 10:47:17');
/*!40000 ALTER TABLE `rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_log`
--

DROP TABLE IF EXISTS `security_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip`),
  KEY `idx_event` (`event_type`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_log`
--

LOCK TABLES `security_log` WRITE;
/*!40000 ALTER TABLE `security_log` DISABLE KEYS */;
INSERT INTO `security_log` VALUES (71,'::1','csrf','CSRF token validation failed on login','2026-06-18 08:55:54'),(72,'::1','csrf','CSRF token validation failed on form submission','2026-06-18 08:55:54'),(73,'::1','csrf','CSRF token validation failed on form submission','2026-06-18 08:55:54'),(74,'::1','failed_login','Failed login for: admin','2026-06-18 08:55:54'),(75,'::1','failed_login','Failed login for: admin','2026-06-18 08:55:54'),(76,'::1','failed_login','Failed login for: admin','2026-06-18 08:55:54'),(77,'::1','failed_login','Failed login for: admin','2026-06-18 08:55:55'),(78,'::1','brute_force','Brute force detected: 5 attempts','2026-06-18 08:55:55'),(79,'::1','honeypot','Bot detected via honeypot','2026-06-18 08:55:55'),(80,'::1','honeypot','Bot detected via honeypot','2026-06-18 09:19:36'),(81,'::1','csrf','CSRF token validation failed on login','2026-06-18 09:32:24'),(82,'::1','csrf','CSRF token validation failed on form submission','2026-06-18 09:32:24'),(83,'::1','csrf','CSRF token validation failed on form submission','2026-06-18 09:32:24'),(84,'::1','failed_login','Failed login for: admin','2026-06-18 09:32:24'),(85,'::1','failed_login','Failed login for: admin','2026-06-18 09:32:25'),(86,'::1','failed_login','Failed login for: admin','2026-06-18 09:32:25'),(87,'::1','brute_force','Brute force detected: 5 attempts','2026-06-18 09:32:25'),(88,'::1','honeypot','Bot detected via honeypot','2026-06-18 09:32:25');
/*!40000 ALTER TABLE `security_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `duration` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `requires_payment` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'Saç Kesimi',30,150.00,0,1,'2026-06-18 08:20:11'),(2,'Sakal Tıraşı',20,80.00,1,1,'2026-06-18 08:20:11'),(3,'Saç + Sakal',45,200.00,0,1,'2026-06-18 08:20:11'),(4,'Cilt Bakımı',45,250.00,1,1,'2026-06-18 08:20:11'),(5,'Saç Boyama',60,350.00,1,1,'2026-06-18 08:20:11');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'mail_smtp_host','smtp.gmail.com','2026-06-18 09:34:18'),(2,'mail_smtp_port','587','2026-06-18 09:34:18'),(3,'mail_smtp_secure','tls','2026-06-18 09:34:18'),(4,'mail_smtp_auth','1','2026-06-18 09:34:18'),(5,'mail_smtp_username','','2026-06-18 09:34:18'),(6,'mail_smtp_password','','2026-06-18 09:34:18'),(7,'mail_from_email','','2026-06-18 09:34:18'),(8,'mail_from_name','Randevu Sistemi','2026-06-18 09:34:18'),(9,'sms_provider','log','2026-06-18 09:34:18'),(10,'sms_twilio_sid','','2026-06-18 09:34:18'),(11,'sms_twilio_token','','2026-06-18 09:34:18'),(12,'sms_twilio_from','','2026-06-18 09:34:18'),(13,'sms_netgsm_user','','2026-06-18 09:34:18'),(14,'sms_netgsm_pass','','2026-06-18 09:34:18'),(15,'sms_netgsm_msgheader','','2026-06-18 09:34:18'),(16,'payment_provider','iyzico','2026-06-18 09:34:18'),(17,'payment_iyzico_api_key','sandbox-','2026-06-18 09:34:18'),(18,'payment_iyzico_secret_key','sandbox-','2026-06-18 09:34:18'),(19,'payment_iyzico_sandbox','1','2026-06-18 09:34:18'),(20,'payment_iyzico_base_url','https://sandbox-api.iyzipay.com','2026-06-18 09:34:18'),(21,'app_language','tr','2026-06-18 10:39:50'),(22,'app_language_auto','1','2026-06-18 10:39:50'),(23,'app_short_name','Randevu','2026-06-18 10:39:50'),(24,'app_theme_color','#4F46E5','2026-06-18 10:39:50'),(25,'app_bg_color','#F9FAFB','2026-06-18 10:39:50'),(26,'api_enabled','1','2026-06-18 10:39:50'),(27,'api_key','','2026-06-18 10:39:50'),(28,'backup_auto_enabled','0','2026-06-18 10:39:50'),(29,'backup_frequency','daily','2026-06-18 10:39:50'),(30,'backup_retention','7','2026-06-18 10:39:50'),(31,'last_backup','2026-06-18 12:40:23','2026-06-18 10:40:23'),(32,'last_backup_file','backup_manual_20260618_124022.sql.gz','2026-06-18 10:40:23'),(33,'mysqldump_path','','2026-06-18 10:39:50'),(34,'sentry_dsn','','2026-06-18 10:39:50'),(35,'error_log_level','2','2026-06-18 10:39:50'),(36,'cache_type','file','2026-06-18 10:39:50'),(37,'cache_server','127.0.0.1','2026-06-18 10:39:50'),(38,'cache_port','6379','2026-06-18 10:39:50'),(39,'cache_prefix','randv_','2026-06-18 10:39:50'),(40,'cache_ttl','3600','2026-06-18 10:39:50');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_hours`
--

DROP TABLE IF EXISTS `working_hours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `working_hours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day_of_week` tinyint(4) NOT NULL,
  `is_open` tinyint(1) DEFAULT 1,
  `open_time` time DEFAULT '09:00:00',
  `close_time` time DEFAULT '18:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_hours`
--

LOCK TABLES `working_hours` WRITE;
/*!40000 ALTER TABLE `working_hours` DISABLE KEYS */;
INSERT INTO `working_hours` VALUES (1,0,0,NULL,NULL),(2,1,1,'09:00:00','18:00:00'),(3,2,1,'09:00:00','18:00:00'),(4,3,1,'09:00:00','18:00:00'),(5,4,1,'09:00:00','18:00:00'),(6,5,1,'09:00:00','18:00:00'),(7,6,1,'10:00:00','16:00:00');
/*!40000 ALTER TABLE `working_hours` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-18 13:47:18
